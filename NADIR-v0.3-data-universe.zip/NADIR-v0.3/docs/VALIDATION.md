# Scientific Validation

## Current automated tests

The v0.3 test binary checks:

- WGS84 geodetic/ECEF round trip
- SHA-256 known vector
- JPL Horizons CSV vector parsing
- internal JSON parsing
- OMM parsing with a six-digit catalog identifier
- OMM search by numeric catalog identifier
- UTC/TAI leap-second state for 2017-01-01
- UT1 offset arithmetic
- IERS EOP CSV parsing
- EOP interpolation and prediction propagation
- USGS earthquake GeoJSON normalization
- JPL fireball normalization and hemisphere signs
- Doppler sign behavior

## Required validation before N5 is marked complete

SGP4 must be validated against the Vallado/CelesTrak reference implementation and verification cases. NADIR will not mark orbital propagation complete based only on a visually plausible track.

Required checks:

```text
reference TLE/OMM input
reference gravity constants/configuration
TEME position error
TEME velocity error
near-Earth cases
deep-space cases
high-eccentricity cases
resonance cases
negative/positive propagation times
six-digit catalog identity handling outside fixed-width TLE
```

## Frame validation

TEME-to-ITRF validation will compare against established Vallado conversion cases with IERS EOP inputs. The future GCRF/CIRS/TIRS chain will be validated against SOFA/ERFA-compatible reference results or equivalent authoritative test material.

## Ephemeris validation

JPL Horizons and SPICE-derived states will retain target, center, epoch, time scale, units and reference-plane metadata. Cross-checks must compare like-for-like frames and centers.
